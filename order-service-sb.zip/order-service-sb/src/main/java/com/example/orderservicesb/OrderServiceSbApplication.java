package com.example.orderservicesb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderServiceSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderServiceSbApplication.class, args);
	}

}
