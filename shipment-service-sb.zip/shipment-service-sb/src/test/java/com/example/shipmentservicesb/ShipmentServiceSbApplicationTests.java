package com.example.shipmentservicesb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShipmentServiceSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
