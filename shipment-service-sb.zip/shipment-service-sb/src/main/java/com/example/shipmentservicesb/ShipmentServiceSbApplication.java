package com.example.shipmentservicesb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShipmentServiceSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShipmentServiceSbApplication.class, args);
	}

}
